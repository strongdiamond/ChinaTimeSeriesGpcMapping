# -*- coding: utf-8 -*-
import os
import sys
from pathlib import Path
import datetime
import re
from tensorboardX import SummaryWriter
import torch
sys.path.append('.')
from tools.modelBuilder import modelCreateAC
from engine.engine import train_one_epoch,val_one_epoch
from utility.logger import create_logger
from utility.utils import (set_seed,build_traininfo_dirs,get_parser,get_criterion,EarlyStopping)
from utility.optimizer import get_optimizer
from utility.lr_scheduler import build_scheduler_epoch
from configs.configsPy.config_pt import get_configA
from samples_provider.build_loader import build_loader
import warnings
warnings.filterwarnings("ignore")

#====================================================================================
def getMaxDateStr(configInfo):
    all_weights=sorted(Path(f'{configInfo.TRAIN.WORK_DIR}/checkpoints').glob('*.pth'))
    if len(all_weights)>0:
        date_lst=[re.findall(r'\d{12}',item.stem)[0] for item in all_weights  if len(item.stem.split('_'))>9]
        if len(date_lst)>0:
            max_date=max([datetime.datetime.strptime(item, r"%Y%m%d%H%M") for item in date_lst])
            max_date_str=datetime.datetime.strftime(max_date, r"%Y%m%d%H%M")
            return max_date_str
        else:
            return None
#===================================================================================

def modelTrainingAC(configInfo):
    startDateTime_str=datetime.datetime.now().strftime(r'%Y%m%d%H%M')
    
    print('#----------Preparing dir----------#')
    #20250701
    sys.path.append(configInfo.TRAIN.WORK_DIR + '/')
    checkpoint_dir,logs_dir,summary_dir=build_traininfo_dirs(configInfo)
    weightName=f'{configInfo.TRAIN.WEIGHTS_PREFIX}_{configInfo.TRAIN.EPOCHS}_best_{startDateTime_str}.pth'
    best_weights_filepath=os.path.join(checkpoint_dir,weightName)
    #**********************************************************************
    print('#----------Creating logger----------#')
    logger = create_logger(logs_dir=logs_dir, logfieName='gpc_yrbasin',logger_name=f"{configInfo.MODEL.NAME}")
    # global writer
    writer = SummaryWriter(summary_dir)
   
    print('#---------------------------GPU init---------------------#')
    os.environ["CUDA_VISIBLE_DEVICES"] = str(configInfo.TRAIN.GPU_ID)
    print(f'torch.cuda.is_available()>>>>>>>{torch.cuda.is_available()}')
    torch.cuda.set_device("cuda:0")
    set_seed(configInfo.TRAIN.SEED)
    torch.cuda.empty_cache()

    print('#----------Preparing dataset----------#')
    train_loader,val_loader=build_loader(configInfo)

    print('#--------------------Prepareing Model-------------------------#')
    model = modelCreateAC(configInfo).cuda()
    print('#----------Prepareing loss, opt, sch and amp----------#')
    criterion = get_criterion(configInfo)
    optimizer = get_optimizer(configInfo, model)
    lr_scheduler = build_scheduler_epoch(configInfo, optimizer)
    early_stopping = EarlyStopping(patience=70, save_path=os.path.join(checkpoint_dir, 'best.pth'))
    print('#----------------Set other params---------------------#')
    min_loss = 999
    start_epoch = configInfo.TRAIN.START_EPOCH
    min_epoch = 1
    maxDateStr=getMaxDateStr(configInfo)
    resume_model = os.path.join(checkpoint_dir, f'latest_{maxDateStr}.pth')

    if os.path.exists(resume_model):
        weightName=f'{configInfo.TRAIN.WEIGHTS_PREFIX}_{configInfo.TRAIN.EPOCHS*configInfo.TRAIN.TIMES}_best_{startDateTime_str}.pth'
        print('#----------Resume Model and Other params----------#')
        device = torch.device('cuda:0' if torch.cuda.is_available() else 'cpu')
        checkpoint = torch.load(resume_model, map_location=device,weights_only=False)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        lr_scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        saved_epoch = checkpoint['epoch']
        start_epoch += saved_epoch
        min_loss, min_epoch, val_loss = checkpoint['min_loss'], checkpoint['min_epoch'], checkpoint['val_loss']

        log_info = (f'resuming model from {resume_model}. resume_epoch: {saved_epoch}, min_loss: {min_loss:.4f},'
                    f'min_epoch: {min_epoch}, val_loss: {val_loss:.4f}')
        logger.info(log_info)

    step = 0
    print('#-----------------------------------Training--------------------------------#')
    for epoch in range(configInfo.TRAIN.START_EPOCH, configInfo.TRAIN.EPOCHS+1):
        torch.cuda.empty_cache()
        step=train_one_epoch(model,criterion, optimizer, lr_scheduler,epoch, step,writer,configInfo,train_loader)
        val_loss=val_one_epoch(model,criterion, epoch,writer,configInfo,val_loader)
        if val_loss < min_loss:
            torch.save(optimizer.state_dict(), os.path.join(checkpoint_dir, 'optimizer_state_dict_best.pth'))
            min_loss = val_loss
            min_epoch = epoch
        # 早停判断 + 保存最优模型
        early_stopping(val_loss, model)

        torch.save({'epoch': epoch,'min_loss': min_loss,'min_epoch': min_epoch,'val_loss': val_loss,
                    'model_state_dict': model.state_dict(),
                    'optimizer_state_dict': optimizer.state_dict(),
                    'scheduler_state_dict': lr_scheduler.state_dict(),}, 
                    os.path.join(checkpoint_dir, f'latest_{startDateTime_str}.pth'))
        if early_stopping.early_stop:
            print("触发早停，终止训练！")
            break

    if Path(checkpoint_dir).joinpath('best.pth').exists():
        Path(checkpoint_dir).joinpath('best.pth').rename(best_weights_filepath)
        print(f'best.pth 已重新命名为{Path(best_weights_filepath).name}')

    print(f"\n最后一轮模型已保存至 {os.path.join(checkpoint_dir, f'latest_{startDateTime_str}.pth')}")
    writer.close()
    print("TensorBoard日志已保存,可启动面板查看")
#=============================================================================================================
if __name__ == '__main__':
    #***********************************************************************************************************
    configYamlFile=Path('./configs/configsYaml/chinaGpc/MambaUnet_chinaGpc_256sz.yaml')
    #***********************************************************************************************************
    parser=get_parser()
    args, unparsed = parser.parse_known_args("--batch-size 4 --tile-size 256 --tile-channels 12 --valid-nums 1262 "
                                            "--end-epoch 150 --num-classes 1".split())
    #***********************************************************************************************************
    configInfo = get_configA(args,configYamlFile)
    modelTrainingAC(configInfo)