# -*- coding: utf-8 -*-
import os
import sys
import yaml
from yacs.config import CfgNode as CN
sys.path.append('.')
#=================================================================================
_C = CN()

# Base config files
_C.BASE = ['']

# -----------------------------------------------------------------------------
# Data settings
# -----------------------------------------------------------------------------
_C.DATA = CN()
_C.DATA.DATA_PATH='/samples/China_GPC'
_C.DATA.DATASET='china_allyears_gpcsamples_trainval'
_C.DATA.VALID_NUMS=20
_C.DATA.BATCH_SIZE=8
_C.DATA.TILE_SIZE=256
_C.DATA.TILE_CHANNELS=12
_C.DATA.IMGS_FOLDER=''
_C.DATA.GTS_FOLDER=''
_C.DATA.IMG_SUFFIX=''
_C.DATA.GT_SUFFIX=''
# Pin CPU memory in DataLoader for more efficient (sometimes) transfer to GPU.
_C.DATA.PIN_MEMORY = True
# Number of data loading threads
_C.DATA.NUM_WORKERS = 8
# -----------------------------------------------------------------------------
# Model settings
# -----------------------------------------------------------------------------
_C.MODEL = CN()
_C.MODEL.TYPE='swin'
_C.MODEL.NAME='MambaUnet'
_C.MODEL.NUM_CLASSES=1
_C.MODEL.PRETRAIN_CKPT = None
# Dropout rate
_C.MODEL.DROP_RATE = 0.0
# Drop path rate
_C.MODEL.DROP_PATH_RATE = 0.1
# Label Smoothing
_C.MODEL.LABEL_SMOOTHING = 0.1
_C.MODEL.LOAD_CKPT_PATH=None

# MambaUNet VSSM parameters
_C.MODEL.VSSM = CN()
_C.MODEL.VSSM.PATCH_SIZE = 4
_C.MODEL.VSSM.IN_CHANS = 12
_C.MODEL.VSSM.EMBED_DIM = 96
_C.MODEL.VSSM.DEPTHS = [2, 2, 9, 2]
_C.MODEL.VSSM.MLP_RATIO = 4.
_C.MODEL.VSSM.PATCH_NORM = True
# -----------------------------------------------------------------------------
# Training settings
# -----------------------------------------------------------------------------
_C.TRAIN = CN()
_C.TRAIN.WORK_DIR=''
_C.TRAIN.WEIGHTS_PREFIX=''
_C.TRAIN.START_EPOCH = 1
_C.TRAIN.EPOCHS = 150
_C.TRAIN.WARMUP_EPOCHS = 10
_C.TRAIN.WEIGHT_DECAY = 0.05
_C.TRAIN.BASE_LR = 5e-4
_C.TRAIN.WARMUP_LR = 5e-7
_C.TRAIN.MIN_LR = 5e-6
_C.TRAIN.USE_CHECKPOINT = False
_C.TRAIN.CRITERION='BinaryFocalTverskyLoss'
_C.TRAIN.PRINT_INTERVAL=100
_C.TRAIN.GPU_ID=0
_C.TRAIN.SEED=42
_C.TRAIN.TIMES=1

# LR scheduler
_C.TRAIN.LR_SCHEDULER = CN()
_C.TRAIN.LR_SCHEDULER.NAME = 'cosine'
_C.TRAIN.LR_SCHEDULER.DECAY_EPOCHS = 10
_C.TRAIN.LR_SCHEDULER.DECAY_RATE = 0.1
_C.TRAIN.LR_SCHEDULER.WARMUP_PREFIX = True
_C.TRAIN.LR_SCHEDULER.GAMMA = 0.1
_C.TRAIN.LR_SCHEDULER.MULTISTEPS = []
_C.TRAIN.LR_SCHEDULER.WARM_UP_EPOCHS=10
_C.TRAIN.LR_SCHEDULER.MILESTONES=[125, 225]


# Optimizer
_C.TRAIN.OPTIMIZER = CN()
_C.TRAIN.OPTIMIZER.NAME = 'AdamW'
# Optimizer Epsilon
_C.TRAIN.OPTIMIZER.EPS = 1e-8
# Optimizer Betas
_C.TRAIN.OPTIMIZER.BETAS = (0.9, 0.999)
_C.TRAIN.OPTIMIZER.MOMENTUM = 0.9
_C.TRAIN.OPTIMIZER.LR = 1e-3
_C.TRAIN.OPTIMIZER.WEIGHT_DECAY=1e-2
_C.TRAIN.OPTIMIZER.AMSGRAD=False
# -----------------------------------------------------------------------------
# validate settings
# -----------------------------------------------------------------------------
_C.VALID = CN()
_C.VALID.VAL_INTERVAL=5
_C.VALID.THRESHOLD=0.5
# -----------------------------------------------------------------------------
# Test settings
# -----------------------------------------------------------------------------
_C.TEST = CN()
_C.TEST.BIG_IMGS_DIR=''
_C.TEST.BIG_IMGS_RESULT=''
_C.TEST.TEST_IMGS_DIR=''
_C.TEST.TEST_IMGS_RESULT=''
#===============================================================================================
#**********************************************************************************
def _update_config_from_file(config, cfg_file):
    config.defrost()
    with open(cfg_file, 'r') as f:
        yaml_cfg = yaml.load(f, Loader=yaml.FullLoader)

    for cfg in yaml_cfg.setdefault('BASE', ['']):
        if cfg:
            _update_config_from_file(
                config, os.path.join(os.path.dirname(cfg_file), cfg)
            )
    print('=> merge config from {}'.format(cfg_file))
    config.merge_from_file(cfg_file)
    config.freeze()

#**********************************************************************************
#=============================================================================================
def _update_config_from_fileA(config, cfg_file):
    modelConfig_Dir='./configs/configs_model'
    config.defrost()
    with open(cfg_file, 'r') as f:
        yaml_cfg = yaml.load(f, Loader=yaml.FullLoader)

    for cfg in yaml_cfg.setdefault('BASE', ['']):
        if cfg:
            _update_config_from_file(
                config, os.path.join(modelConfig_Dir, cfg)
            )
    print('=> merge config from {}'.format(cfg_file))
    config.merge_from_file(cfg_file)
    config.freeze()
##=============================================================================================
def update_configA(config,args,yaml_fullpath):
    if yaml_fullpath is not None:
        _update_config_from_fileA(config, yaml_fullpath)

    config.defrost()
    if args.opts is not None:
        config.merge_from_list(args.opts)

    def _check_args(name):
        if hasattr(args, name) and eval(f'args.{name}'):
            return True
        return False

    # merge from specific arguments
    if _check_args('batch_size'):
        config.DATA.BATCH_SIZE = args.batch_size
    if _check_args('tile_size'):
        config.DATA.TILE_SIZE = args.tile_size
    if _check_args('tile_channels'):
        config.DATA.TILE_CHANNELS = args.tile_channels
    if _check_args('valid_nums'):
        config.DATA.VALID_NUMS = args.valid_nums
    if _check_args('data_path'):
        config.DATA.DATA_PATH = args.data_path
    if _check_args('num_classes'):
        config.MODEL.NUM_CLASSES = args.num_classes
    if _check_args('pretrained'):
        config.MODEL.PRETRAINED = args.pretrained
    if _check_args('resume'):
        config.MODEL.RESUME = args.resume
    if _check_args('end_epoch'):
        config.TRAIN.EPOCHS = args.end_epoch
    if _check_args('use_checkpoint'):
        config.TRAIN.USE_CHECKPOINT = True
    if _check_args('train_times'):
        config.TRAIN.TIMES = args.train_times

    config.freeze()
##*******************************************************************************************
def get_configA(args,yaml_fullpath):
    config = _C.clone()
    if args is not None and yaml_fullpath is not None:
        update_configA(config,args,yaml_fullpath)
    elif yaml_fullpath is not None:
        _update_config_from_fileA(config, yaml_fullpath)
    else:
        print('a default config is adopted!!!')    

    return config

#===============================================================================================
if __name__=='__main__':
   
    pass