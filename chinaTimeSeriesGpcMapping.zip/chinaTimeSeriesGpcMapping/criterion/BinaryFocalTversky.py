# -*- coding: utf-8 -*-
import torch
import torch.nn as nn
import torch.nn.functional as F
##===================================================================================================
class BinaryTverskyLoss(nn.Module):
    def __init__(self, alpha=0.3, beta=0.7, smooth=1e-6):
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.smooth = smooth
    def forward(self, logits, label):
        pred = torch.sigmoid(logits)
        TP = (pred * label).sum(dim=(2,3))
        FP = (pred * (1-label)).sum(dim=(2,3))
        FN = ((1-pred) * label).sum(dim=(2,3))
        ti = (TP+self.smooth)/(TP+self.alpha*FP+self.beta*FN+self.smooth)
        return 1 - ti.mean()
##===================================================================================================
class BinaryFocalLoss(nn.Module):
    def __init__(self, alpha=0.25, gamma=2, reduction="mean"):
        super().__init__()
        self.alpha = alpha
        self.gamma = gamma
        self.reduction = reduction

    def forward(self, pred_logits, target):
        pred = torch.sigmoid(pred_logits)
        
        bce = F.binary_cross_entropy(pred, target, reduction="none")

        
        p_t = pred * target + (1 - pred) * (1 - target)
        focal_weight = (1 - p_t) ** self.gamma

       
        alpha_t = self.alpha * target + (1-self.alpha) * (1 - target)
        focal_weight = alpha_t * focal_weight

        loss = focal_weight * bce

        if self.reduction == "mean":
            return loss.mean()
        elif self.reduction == "sum":
            return loss.sum()
        else:
            return loss
##===================================================================================================
class BinaryFocalTverskyLoss(nn.Module):
    def __init__(self, fl_alpha=0.25, gamma=2, alpha=0.3, beta=0.7,smooth=1e-6):
        super().__init__()
        self.focal = BinaryFocalLoss(alpha=fl_alpha, gamma=gamma)
        self.tversky = BinaryTverskyLoss(alpha=alpha, beta=beta,smooth=smooth)

    def forward(self, pred_logits, label):
        return self.focal(pred_logits, label) + self.tversky(pred_logits, label)
#===================================================================================================

if __name__ == "__main__":
   pass
