# -*- coding: utf-8 -*-
import time
import datetime
import logging
import numpy as np
from tqdm import tqdm
import torch
from torch.cuda.amp import autocast as autocast
from sklearn.metrics import confusion_matrix
#==========================================================================================
def meanIntersectionOverUnion(confusionMatrix):
    intersection = np.diag(confusionMatrix)
    union = np.sum(confusionMatrix, axis=1) + np.sum(confusionMatrix, axis=0) - np.diag(
        confusionMatrix)
    IoU = intersection / union
    mIoU = np.nanmean(IoU)
    return mIoU
##*************************************************************************************
def accuracy_metrics_mannually(gts,preds):
    cm=confusion_matrix(y_true=gts, y_pred=preds)
    mIOU=meanIntersectionOverUnion(cm)
    intersection = np.diag(cm)
    preds_totalNum=np.sum(cm,axis=0)
    gts_totalNum=np.sum(cm,axis=1)
    precision_val=intersection/preds_totalNum
    recall_val=intersection/gts_totalNum
    f1_val1=(2*precision_val*recall_val)/(precision_val+recall_val)
    f1_val2=(2*intersection)/(gts_totalNum+preds_totalNum)
    #************************************************************************
    oa=intersection.sum()/cm.sum()
    return cm,precision_val,recall_val,f1_val1,f1_val2,mIOU,oa
#==========================================================================================
def train_one_epoch(model,criterion, optimizer, scheduler,epoch, step,writer,config,train_loader):
    '''
    train model for one epoch
    '''
    logger = logging.getLogger(f"{config.MODEL.NAME}")
    # switch to train mode
    model.train() 
 
    loss_lst = []
    start = time.time()
    for iter, data in enumerate(train_loader):
        step += iter
        optimizer.zero_grad()
        images, targets = data
        images, targets = images.cuda(non_blocking=True).float(), targets.cuda(non_blocking=True).float()

        out = model(images)
        train_loss = criterion(out, targets)

        train_loss.backward()
        optimizer.step()
        
        loss_lst.append(train_loss.item())

        now_lr = optimizer.state_dict()['param_groups'][0]['lr']
        if iter % config.TRAIN.PRINT_INTERVAL == 0:
            log_info = f'train: epoch {epoch}/{config.TRAIN.EPOCHS}, iter:{iter}, loss: {np.mean(loss_lst):.4f}, lr: {now_lr}'
            # print(log_info)
            logger.info(log_info)
    ##******************************TensorBoard 日志写入**************************************
    # 写入损失-学习率曲线
    writer.add_scalar("Loss/Train", np.mean(loss_lst), epoch)
    writer.add_scalar("LR/LearningRate", now_lr, epoch)
    ##******************************************************************************
    scheduler.step(epoch)
    epoch_time = time.time() - start
    logger.info(f"EPOCH {epoch}/{config.TRAIN.EPOCHS} training takes {datetime.timedelta(seconds=int(epoch_time))}")
    return step

#==========================================================================================
@torch.no_grad()
def val_one_epoch(model,criterion, epoch,writer,config,val_loader):
    logger = logging.getLogger(f"{config.MODEL.NAME}")
    # switch to evaluate mode
    model.eval()
    probs_lst = []
    gts_lst = []
    loss_lst = []
    
    for idx, (imgs, gts) in tqdm(enumerate(val_loader)):
        imgs, gts = imgs.cuda(non_blocking=True).float(), gts.cuda(non_blocking=True).float()
        preds = model(imgs)

        loss = criterion(preds, gts)
        loss_lst.append(loss.item())
        probs=torch.sigmoid(preds)
        probs = probs.squeeze(1).cpu().detach().numpy()
        probs_lst.append(probs)
        gts_lst.append(gts.squeeze(1).cpu().detach().numpy())
        ##*************************************************************************
        if idx == 0:
            vis_gt = gts[0:1]
            vis_pred = (torch.sigmoid(preds[0:1]) > 0.5).float()
        ##*************************************************************************        

    if epoch % config.VALID.VAL_INTERVAL == 0:
        probs_epoch = np.vstack(probs_lst).reshape(-1,)
        gts_epoch = np.vstack(gts_lst).reshape(-1,)
        y_preds = np.where(probs_epoch>=config.VALID.THRESHOLD, 1, 0)
        y_trues = np.where(gts_epoch>=0.5, 1, 0)

        confusion,precision_val,recall_val,f1_val,_,mIOU,oa=accuracy_metrics_mannually(y_trues,y_preds)
        ##******************************TensorBoard 日志写入**************************************
        writer.add_scalar("Metrics/mIoU", mIOU, epoch)
        writer.add_scalar("Metrics/f1_val", f1_val[1], epoch)
        writer.add_scalar("Metrics/Recall", recall_val[1], epoch)
        writer.add_scalar("Metrics/Precision", precision_val[1], epoch)
        ##**************************************************************************************************

        log_info = f'val_epoch: {epoch}, val_loss: {np.mean(loss_lst):.4f}, accuracy: {oa}, miou: {mIOU}, f1_or_dsc: {f1_val}, \
                recall: {recall_val}, precision: {precision_val}, confusion_matrix: {confusion}'
        print(log_info)
        logger.info(log_info)

    else:
        log_info = f'val_epoch: {epoch}, val_loss: {np.mean(loss_lst):.4f}'
        print(log_info)
        logger.info(log_info)
    ##******************************TensorBoard 日志写入**************************************
    writer.add_scalar("Loss/Val", np.mean(loss_lst), epoch)
    writer.add_images("Visual/GroundTruth", vis_gt, epoch)
    writer.add_images("Visual/Prediction", vis_pred, epoch)
    ##***************************************************************************************
    return np.mean(loss_lst)
#==========================================================================================
@torch.no_grad()
def test_one_epoch(model,logger,config,img_tensor):
    # switch to evaluate mode
    model.eval()
    img_tensor = img_tensor.cuda(non_blocking=True).float()
    probs = model(img_tensor)
    probs=torch.squeeze(probs)

    mask=(probs>=config.VALID.THRESHOLD).cpu().detach().numpy().astype(np.uint8)
    logger.info('one tile has been inference')
    return mask
#==========================================================================================
if __name__ == '__main__':
    pass