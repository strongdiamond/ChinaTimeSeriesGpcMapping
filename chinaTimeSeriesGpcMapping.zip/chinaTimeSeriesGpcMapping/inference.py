# -*- coding: utf-8 -*-
import os
import sys
import gc
import re
import datetime
from pathlib import Path
import numpy as np
from osgeo import gdal_array
import torch
sys.path.append('.')
from configs.configsPy.config_pt import get_configA
from utility.utils import set_seed,get_parser
from tools.modelBuilder import modelCreateAC
#========================================================================================================================
def derive_prefixNames(imgs_dir,imgSuffix):
    if len(imgSuffix)>0:
        imgs_prefix= sorted([(fname.split(imgSuffix)[0],fname) for fname in os.listdir(imgs_dir)
                                if fname.endswith((".tif",".dat"))])
    else:
        imgs_prefix= sorted([(Path(fname).stem,fname) for fname in os.listdir(imgs_dir)
                                if fname.endswith((".tif",".dat"))])    
    
    return imgs_prefix
#========================================================================================================================
@torch.no_grad()
def binary_inference(configInfo,weight_fullpath,imgSuffix,resultDriver='GTiff'):
    
    result_ext='.tif' if resultDriver=='GTiff' else '.dat'
    resultSuffix=Path(weight_fullpath).stem.split('.')[0]
    print('#---------------------------GPU init---------------------#')
    os.environ["CUDA_VISIBLE_DEVICES"] = str(configInfo.TRAIN.GPU_ID)
    device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    print(f'device>>>>>>>>>>>>>>>>>>>>>>>>>{device}')
    torch.cuda.set_device(device)
    set_seed(configInfo.TRAIN.SEED)
    torch.cuda.empty_cache()
    print('#--------------------Prepareing Model-------------------------#')
    model = modelCreateAC(configInfo).cuda()
    if os.path.exists(weight_fullpath):
        model.load_state_dict(torch.load(weight_fullpath))
        print('load weights==>'+weight_fullpath)
    else:
        raise Exception('failed to load weights')
    
    model.eval()
    print('--------------------------------------------------------------')
    tile_size=configInfo.DATA.TILE_SIZE
    tile_channels=configInfo.DATA.TILE_CHANNELS
    img_year_parentDir=configInfo.TEST.TEST_IMGS_DIR
    year_lst=os.listdir(img_year_parentDir)
    for aYear in year_lst:
        imgs_dir=Path(img_year_parentDir)/f'{aYear}'/'sats'
        predictDir=Path(img_year_parentDir)/f'{aYear}'/'sats_pred'
        predictDir.mkdir(exist_ok=True,parents=True)
        imgs_prefixNames=derive_prefixNames(imgs_dir.as_posix(),imgSuffix)
        for n in range(len(imgs_prefixNames)):
            start=datetime.datetime.now()
            imgFn_prefix,img_fname=imgs_prefixNames[n]
            resultName=imgFn_prefix+'__'+f'{resultSuffix}_mask{result_ext}'
            result_fullpath=predictDir/f'{resultName}'
            img_fullpath=imgs_dir/f'{img_fname}'
            img_npy=gdal_array.LoadFile(img_fullpath)
            img_npy=img_npy if img_npy.shape[2]<=32 else img_npy.transpose([1,2,0])
            oh,ow,b = img_npy.shape
            rh, rw = oh % tile_size, ow % tile_size
            
            height_pad = 0 if rh == 0 else tile_size - rh
            width_pad = 0 if rw == 0 else tile_size - rw
            
            padding_h,padding_w=oh+height_pad,ow+width_pad
            padding_img = np.zeros((padding_h,padding_w,tile_channels),dtype=img_npy.dtype)
            padding_img[0:oh,0:ow,:] = img_npy[:,:,:tile_channels]
            del img_npy
            gc.collect()
            #***********************************************************************
            mask_whole = np.zeros((padding_h,padding_w),dtype=np.uint8)
            
            for i in range(0,padding_h,tile_size):
                for j in range(0,padding_w,tile_size):
                    tile=padding_img[i:i+tile_size,j:j+tile_size,:]
                    tile_tensor=torch.from_numpy(tile).permute(2, 0, 1).float().contiguous()
                    tile_tensor=torch.unsqueeze(tile_tensor, 0) 
                    tile_tensor=tile_tensor.cuda(non_blocking=True)
                    preds_logits = model(tile_tensor)
                    probs=torch.sigmoid(preds_logits)
                    probs=torch.squeeze(probs)
                    mask=probs.cpu().detach().numpy()
                    mask = np.where(mask>0.5, 1, 0)
                    print(f'mask.dtype>>>>>>>>>>>>>>>>{mask.dtype}')
                    mask_whole[i:i+tile_size,j:j+tile_size] = mask[:,:]
            
            gdal_array.SaveArray(mask_whole[0:oh,0:ow]*255,result_fullpath.as_posix(),format=resultDriver,
                                 prototype=img_fullpath.as_posix(),interleave='band')
            del padding_img
            del mask_whole
            gc.collect()
    
            end=datetime.datetime.now()
            elapse=end-start
            print(f'大图预测花费的总时间:{elapse}')

#===================================================================================================
if __name__=="__main__":
    #***********************************************************************************************************
    configYamlFile=Path('./configs/configsYaml/chinaGpc/MambaUnet_chinaGpc_256sz.yaml')
    #***********************************************************************************************************
    parser=get_parser()
    args, unparsed = parser.parse_known_args("--tile-channels 12 --num-classes 1".split())
    configInfo = get_configA(args,configYamlFile)
    #***********************************************************************************************************
    all_weights=sorted(Path(f'{configInfo.TRAIN.WORK_DIR}/checkpoints').glob('*.pth'))
    date_lst=[re.findall(r'\d{12}',item.stem)[0] for item in all_weights  if len(item.stem.split('_'))>9]
    max_date=max([datetime.datetime.strptime(item, r"%Y%m%d%H%M") for item in date_lst])
    max_date_str=datetime.datetime.strftime(max_date, r"%Y%m%d%H%M")
    weight_fn=f'{configInfo.TRAIN.WEIGHTS_PREFIX}_{configInfo.TRAIN.EPOCHS}_best_{max_date_str}.pth'
    weight_fullpath=os.path.join(f'{configInfo.TRAIN.WORK_DIR}/checkpoints',weight_fn)
                                 
    if not Path(weight_fullpath).exists():
        print(f'{weight_fullpath} does not exist!!!!!!!!')
        sys.exit(1)
    #=================================================================================================================
    _imgSuffix='__sats'
    _resultDriver='GTiff'
    binary_inference(configInfo,weight_fullpath,_imgSuffix,_resultDriver)