# -*- coding: utf-8 -*-

from pathlib import Path
import torch
from .samplesReader import BinaryTifReader,get_shuffle_img_gt_train_val_fns
#========================================================================================================================
def build_loader(config):

    imgs_gts_dir=Path(config.DATA.DATA_PATH).joinpath(config.DATA.DATASET)
    train_same_prefix_fnames,valid_same_prefix_fnames=get_shuffle_img_gt_train_val_fns(imgs_gts_dir,config.DATA.IMGS_FOLDER,
                                                                                       config.DATA.IMG_SUFFIX,
                                                                                       val_samples_num=config.DATA.VALID_NUMS,
                                                                                       imgExt='.tif')
    train_set = BinaryTifReader(train_same_prefix_fnames,imgs_gts_dir,
                                 config.DATA.IMGS_FOLDER,config.DATA.GTS_FOLDER,
                                 config.DATA.IMG_SUFFIX,config.DATA.GT_SUFFIX,config.DATA.TILE_CHANNELS)
    val_set = BinaryTifReader(valid_same_prefix_fnames,imgs_gts_dir,
                               config.DATA.IMGS_FOLDER,config.DATA.GTS_FOLDER,
                               config.DATA.IMG_SUFFIX,config.DATA.GT_SUFFIX,config.DATA.TILE_CHANNELS)
 
    train_loader = torch.utils.data.DataLoader(
        train_set, 
        batch_size=config.DATA.BATCH_SIZE,
        shuffle=True,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
        drop_last=True,
    )

    val_loader = torch.utils.data.DataLoader(
        val_set, 
        batch_size=config.DATA.BATCH_SIZE,
        shuffle=False,
        num_workers=config.DATA.NUM_WORKERS,
        pin_memory=config.DATA.PIN_MEMORY,
        drop_last=False
    )

    return  train_loader, val_loader

#========================================================================================================================
def build_dataset(is_train, config):
   pass

#========================================================================================================================
def build_transform(is_train, config):
    pass
#========================================================================================================================
if __name__=='__main__':
    pass