# -*- coding: utf-8 -*-
import os
import random
import tifffile as tiff
import torch
from torch.utils.data import Dataset
#=======================================================================================
#=======================================================================================
def get_imgs_gts_fns(imgs_gts_parentDir,imgsFolder='sats',imgSuffix='__sats',imgExt='.tif'):
    same_prefix_fnames = sorted(
    [
        fname.split(imgSuffix)[0]
        for fname in os.listdir(os.path.join(imgs_gts_parentDir,imgsFolder))
        if fname.endswith(imgExt) and not fname.startswith(".")
    ]
    )
    return same_prefix_fnames
#******************************************************************************************
def get_shuffle_img_gt_train_val_fns(imgs_gts_parentDir,imgsFolder='sats',imgSuffix='__sats',
                                     val_samples_num=300,imgExt='.tif',rand_num=42):
    same_prefix_fnames=get_imgs_gts_fns(imgs_gts_parentDir,imgsFolder,imgSuffix,imgExt)
    random.Random(rand_num).shuffle(same_prefix_fnames)
    train_same_prefix_fnames = same_prefix_fnames[:-val_samples_num]
    valid_same_prefix_fnames = same_prefix_fnames[-val_samples_num:]
    return train_same_prefix_fnames,valid_same_prefix_fnames
#=======================================================================================
class BinaryTifReader(Dataset):
    def __init__(self, same_prefix_fnames,imgs_gts_parentDir,imgsFolder='sats',gtsFolder='gts',
                 imgSuffix='__sats',gtSuffix='__gts',tile_channels=10):
        self._same_prefix_fnames=same_prefix_fnames
        self._imgs_gts_parentDir = imgs_gts_parentDir
        self._imgsFolder=imgsFolder
        self._gtsFolder=gtsFolder
        self._imgSuffix=imgSuffix
        self._gtSuffix=gtSuffix
        self._tile_channels=tile_channels

    def __len__(self):
        return len(self._same_prefix_fnames)

    def __getitem__(self, idx):
       
        img = tiff.imread(os.path.join(self._imgs_gts_parentDir,self._imgsFolder,
                                       self._same_prefix_fnames[idx]+f'{self._imgSuffix}.tif'))
        
        
        img=img[:self._tile_channels,:,:]#>>>当img为channels_first时使用;
        img = torch.from_numpy(img).float()
        ##*************************************************************************************************
        gt = tiff.imread(os.path.join(self._imgs_gts_parentDir,self._gtsFolder,
                                      self._same_prefix_fnames[idx]+f'{self._gtSuffix}.tif'))//255
        gt = torch.from_numpy(gt[None,:,:]).float()
        return img, gt
#=======================================================================================
#=======================================================================================
if __name__=='__main__':
    pass
    