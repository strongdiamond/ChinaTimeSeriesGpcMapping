# -*- coding: utf-8 -*-
import sys

sys.path.append('.')
from models.MambaUNet.vision_mamba import MambaUnet
#===========================================================================================

#================================================================================================================
def modelCreateAC(config):
    if config.MODEL.NAME=='UNet':
        pass
    elif config.MODEL.NAME=='MambaUnet':
        mambaUnet_model=MambaUnet(config)
        mambaUnet_model.load_from(config)
        return mambaUnet_model
    else:
        pass
#===============================================================================================================

if __name__=='__main__':
    
    pass