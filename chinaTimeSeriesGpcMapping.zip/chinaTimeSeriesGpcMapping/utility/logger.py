# -*- coding: utf-8 -*-
import os
import sys
import logging
import logging.handlers
import functools
from termcolor import colored
#=========================================================================================================
#===================================================================================
@functools.lru_cache()
def create_logger(logs_dir, logfieName=None,logger_name=None):
    # create logger
    logger = logging.getLogger(logger_name)
    logger.setLevel(logging.DEBUG)
    logger.propagate = False
    # create formatter
    fmt = '[%(asctime)s %(name)s] (%(filename)s %(lineno)d): %(levelname)s %(message)s'
    color_fmt = colored('[%(asctime)s %(name)s]', 'green') + \
                colored('(%(filename)s %(lineno)d)', 'yellow') + ': %(levelname)s %(message)s'
    
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.DEBUG)
    console_handler.setFormatter(logging.Formatter(fmt=color_fmt, datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(console_handler)

    
    logfile_fullpath = os.path.join(logs_dir, f'{logfieName}_log.txt')
    file_handler=logging.handlers.TimedRotatingFileHandler(logfile_fullpath,when='D',encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter(fmt=fmt, datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(file_handler)

    return logger

#===================================================================================

#===================================================================================
if __name__ == '__main__':
    pass
