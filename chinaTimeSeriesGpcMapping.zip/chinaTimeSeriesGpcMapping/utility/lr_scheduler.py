# -*- coding: utf-8 -*-
from timm.scheduler.cosine_lr import CosineLRScheduler
#===============================================================================================
#===============================================================================================
def build_scheduler_epoch(config, optimizer):
    num_steps = int(config.TRAIN.EPOCHS)
    warmup_steps = int(config.TRAIN.WARMUP_EPOCHS)
    decay_steps = int(config.TRAIN.LR_SCHEDULER.DECAY_EPOCHS)
    multi_steps = [i for i in config.TRAIN.LR_SCHEDULER.MULTISTEPS]

    lr_scheduler = None
    if config.TRAIN.LR_SCHEDULER.NAME == 'cosine':
        lr_scheduler = CosineLRScheduler(
            optimizer,
            t_initial=(num_steps - warmup_steps) if config.TRAIN.LR_SCHEDULER.WARMUP_PREFIX else num_steps,
            lr_min=config.TRAIN.MIN_LR,
            cycle_mul=1.,
            cycle_decay=1.,
            cycle_limit=1,
            warmup_t=warmup_steps,
            warmup_lr_init=config.TRAIN.WARMUP_LR,
            warmup_prefix=config.TRAIN.LR_SCHEDULER.WARMUP_PREFIX,
            t_in_epochs=True,
        )
    elif config.TRAIN.LR_SCHEDULER.NAME == 'linear':
        pass
    elif config.TRAIN.LR_SCHEDULER.NAME == 'step':
        pass
    elif config.TRAIN.LR_SCHEDULER.NAME == 'multistep':
        pass

    return lr_scheduler
#===============================================================================================

#===============================================================================================
if __name__=='__main__':
    
    pass