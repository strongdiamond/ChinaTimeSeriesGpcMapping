# -*- coding: utf-8 -*-
import sys
import torch
sys.path.append('.')
#===============================================================================================

#=====================================================================================================================================
def get_optimizer(config, model):
    assert config.TRAIN.OPTIMIZER.NAME in ['Adam', 'AdamW', 'SGD'], 'Unsupported optimizer!'
   
    if config.TRAIN.OPTIMIZER.NAME == 'Adam':
        return torch.optim.Adam(
            model.parameters(),
            lr = config.TRAIN.OPTIMIZER.LR,
            betas = config.TRAIN.OPTIMIZER.BETAS,
            eps = config.TRAIN.OPTIMIZER.EPS,
            weight_decay = 0.0001,
            amsgrad = config.TRAIN.OPTIMIZER.AMSGRAD
        )
    elif config.TRAIN.OPTIMIZER.NAME == 'AdamW':
        return torch.optim.AdamW(
            model.parameters(),
            lr = config.TRAIN.OPTIMIZER.LR,
            betas = config.TRAIN.OPTIMIZER.BETAS,
            eps = config.TRAIN.OPTIMIZER.EPS,
            weight_decay = config.TRAIN.OPTIMIZER.WEIGHT_DECAY,
            amsgrad = config.TRAIN.OPTIMIZER.AMSGRAD
        )
    else: # default opt is SGD
        return torch.optim.SGD(
            model.parameters(),
            lr = 0.01,
            momentum = 0.9,
            weight_decay = 0.05,
        )
#===============================================================================================
if __name__=='__main__':
    
    pass