# -*- coding: utf-8 -*-
import os
import sys
import argparse
from pathlib import Path
import random
import numpy as np
import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
sys.path.append('.')
from criterion.BinaryFocalTversky import BinaryFocalTverskyLoss
#===============================================================================================
#===============================================================================================
def get_parser():
    #********************************************************************
    parser = argparse.ArgumentParser('training and evaluation script', add_help=False)
    parser.add_argument('--batch-size', type=int, help="batch size for single GPU")
    parser.add_argument('--tile-size', type=int, help="tile size for input image")#added by liujt
    parser.add_argument('--tile-channels', type=int, help="channels numbers for input image")#added by liujt
    parser.add_argument('--valid-nums', type=int, help="valid samples numbers")#added by liujt
    parser.add_argument('--end-epoch', type=int, help="total epoch numbers for training")#added by liujt
    parser.add_argument('--num-classes', type=int, help="classes numbers for segmentation")#added by liujt
    parser.add_argument('--data-path', type=str, help='path to dataset')
    parser.add_argument('--train-times', type=str, help='the times of do training')
    return parser
#===============================================================================================
def set_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    cudnn.benchmark = False
    cudnn.deterministic = True
#===============================================================================================
def build_traininfo_dirs(config):
    checkpoint_dir=os.path.join(config.TRAIN.WORK_DIR,'checkpoints')
    logs_dir=os.path.join(config.TRAIN.WORK_DIR,'logs')
    summary_dir=os.path.join(config.TRAIN.WORK_DIR,'tensorboardVis')
    Path(checkpoint_dir).mkdir(exist_ok=True, parents=True)
    Path(logs_dir).mkdir(exist_ok=True, parents=True)
    Path(summary_dir).mkdir(exist_ok=True, parents=True)
    return checkpoint_dir,logs_dir,summary_dir
#**********************************************************************************
def build_test_dirs(config,is_test=True):
   
    if is_test:
        Result_dir=Path(config.TEST.TEST_IMGS_DIR).parent/'testImg_result'
    else:
        Result_dir=Path(config.TEST.BIG_IMGS_DIR).parent /'bigImg_result'
        
    Result_dir.mkdir(exist_ok=True, parents=True)
    return Result_dir.as_posix()
#========================================================================================================================================
def get_criterion(config):
    if config.TRAIN.CRITERION=='BCELoss':
        return nn.BCELoss()
    elif config.TRAIN.CRITERION=='BCEWithLogitsLoss':
        return nn.BCEWithLogitsLoss()
    elif config.TRAIN.CRITERION=='BinaryFocalTverskyLoss':
        return BinaryFocalTverskyLoss(fl_alpha=0.25, gamma=2, alpha=0.3, beta=0.7,smooth=1e-6)
    else:
         return nn.BCEWithLogitsLoss()
#=====================================================================================================================================
class EarlyStopping:
    def __init__(self, patience=5, verbose=True,min_delta=0.0001, save_path="best.pth"):
        self.patience = patience
        self.verbose = verbose
        self.min_delta = min_delta
        self.save_path = save_path
        self.counter = 0
        self.best_loss = None
        self.early_stop = False
        self.val_loss_min = np.inf

    def __call__(self, val_loss, model):
        if self.best_loss is None:
            self.best_loss = val_loss
            self.save_checkpoint(val_loss,model)
        elif val_loss > self.best_loss - self.min_delta:
            self.counter += 1
            print(f"早停计数器: {self.counter}/{self.patience}")
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_loss = val_loss
            self.save_checkpoint(val_loss,model)
            self.counter = 0

    def save_checkpoint(self, val_loss, model):
        '''Saves model when validation loss decrease.'''
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f})>>>Saving model ...')
        torch.save(model.state_dict(), self.save_path)
        self.val_loss_min = val_loss
        print(f"最优模型已保存至 {self.save_path}")
#===============================================================================================
if __name__=='__main__':
    
    pass